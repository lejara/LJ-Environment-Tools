# SPDX-License-Identifier: GPL-3.0-or-later
"""``image_dump/`` previews for the trim pickers.

Uses ``bpy.utils.previews``, which loads straight off disk and adds **no Image
datablock to the .blend** - important, because the point of this add-on is that
the user's scene is untouched by trim data. ``EnumProperty`` items carry an
``icon_value``, so the dropdown itself shows the texture.

Loaded lazily and one at a time: a dump with hundreds of textures would stall
the panel if it warmed the whole set on first draw. Entries are keyed by
``(root, asset_base_name)`` and invalidated when the chosen file's mtime moves,
so re-exporting a texture from Substance refreshes it.
"""

import os

import bpy.utils.previews

from . import project

_collection = None
#: cache key -> (preview name, resolved path, mtime_ns) for mtime invalidation
_entries = {}
#: assets whose image could not be found, so a miss costs one listdir, not many
_misses = set()


def register():
    global _collection
    if _collection is None:
        _collection = bpy.utils.previews.new()


def unregister():
    global _collection
    if _collection is not None:
        bpy.utils.previews.remove(_collection)
        _collection = None
    _entries.clear()
    _misses.clear()


def invalidate():
    """Drop everything. Cheap - previews reload on next request."""
    if _collection is not None:
        _collection.clear()
    _entries.clear()
    _misses.clear()


def icon_for(root, asset_base_name):
    """``icon_value`` for an asset's representative texture, or 0.

    0 is a valid "no icon" for ``EnumProperty`` items, so callers do not have to
    branch on a missing file.
    """
    if _collection is None or not root or not asset_base_name:
        return 0

    key = "%s|%s" % (root, asset_base_name)
    if key in _misses:
        return 0

    entry = _entries.get(key)
    if entry is not None:
        name, path, stamp = entry
        if _stamp(path) == stamp:
            preview = _collection.get(name)
            if preview is not None:
                return preview.icon_id
        # The file moved or was rewritten - fall through and reload.
        _forget(key)

    path = project.find_asset_image(root, asset_base_name)
    if path is None:
        _misses.add(key)
        return 0

    name = "ljtm_%d" % (abs(hash(key)) % (10 ** 12))
    try:
        preview = _collection.load(name, path, 'IMAGE')
    except (KeyError, RuntimeError):
        # Already loaded under that name, or an unreadable file.
        preview = _collection.get(name)
        if preview is None:
            _misses.add(key)
            return 0

    _entries[key] = (name, path, _stamp(path))
    return preview.icon_id


def _forget(key):
    entry = _entries.pop(key, None)
    if entry and _collection is not None:
        try:
            del _collection[entry[0]]
        except KeyError:
            pass


def _stamp(path):
    try:
        return os.stat(path).st_mtime_ns
    except OSError:
        return None

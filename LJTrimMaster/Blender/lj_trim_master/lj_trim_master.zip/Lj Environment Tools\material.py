# SPDX-License-Identifier: GPL-3.0-or-later
"""Convenience: build a Principled material from one ``image_dump/`` texture.

**Nothing in this add-on depends on it.** The trim transform never inspects a
material - no texture lookup, no filename inference - so the material a slot
carries may already exist, come from another pipeline, or have no image texture
at all. This module only saves the user a few minutes at the start of a model.

That independence is the point of the "sheet material in Blender: cut" decision:
each downstream integration handles its own materials, and the viewport keeps
showing the individual texture at full resolution while modelling rather than a
small corner of a packed sheet.
"""

import os

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Operator

from . import project, settings

_ENUM_KEEPALIVE = {}


def asset_items(_self, context):
    root = settings.project_root(context)
    items = [
        (base_name, base_name, ", ".join(sorted(suffix or "(no suffix)" for suffix in maps)))
        for base_name, maps in project.scan_assets(root)
    ]
    if not items:
        items = [('__none__', "(image_dump is empty)", "Put textures in <project>/image_dump")]
    _ENUM_KEEPALIVE["assets"] = items
    return items


def load_image(path, non_color=False):
    """Load or reuse an Image datablock for *path*."""
    absolute = os.path.abspath(path)
    for image in bpy.data.images:
        if image.filepath and os.path.abspath(bpy.path.abspath(image.filepath)) == absolute:
            return image
    image = bpy.data.images.load(absolute)
    if non_color:
        try:
            image.colorspace_settings.name = 'Non-Color'
        except TypeError:
            pass
    return image


def build_material(root, base_name):
    """A Principled material named *base_name*. Returns ``(material, warnings)``.

    BaseColor is wired if a base-colour-ish sibling exists; Normal is wired
    through a Normal Map node if one exists. A missing map warns and is skipped -
    per the tool's own rule, a missing source never blocks.
    """
    warnings = []
    siblings = dict(project.asset_siblings(root, base_name))

    material = bpy.data.materials.get(base_name)
    if material is None:
        material = bpy.data.materials.new(base_name)
    material.use_nodes = True
    tree = material.node_tree

    principled = next(
        (node for node in tree.nodes if node.type == 'BSDF_PRINCIPLED'), None
    )
    if principled is None:
        principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
        principled.location = (0, 0)
        output = next((n for n in tree.nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if output is None:
            output = tree.nodes.new('ShaderNodeOutputMaterial')
            output.location = (300, 0)
        tree.links.new(principled.outputs['BSDF'], output.inputs['Surface'])

    base_path = _pick(siblings, project.BASE_COLOR_SUFFIXES)
    if base_path is None:
        warnings.append("'%s' has no base colour map - left untextured" % base_name)
    else:
        texture = tree.nodes.new('ShaderNodeTexImage')
        texture.location = (-400, 100)
        texture.image = load_image(base_path)
        texture.label = "BaseColor"
        tree.links.new(texture.outputs['Color'], principled.inputs['Base Color'])

    normal_path = _pick(siblings, project.NORMAL_SUFFIXES)
    if normal_path is None:
        # Explicitly a warning, not an error - Draft asks for exactly this.
        warnings.append("'%s' has no normal map - that is fine" % base_name)
    else:
        texture = tree.nodes.new('ShaderNodeTexImage')
        texture.location = (-600, -250)
        texture.image = load_image(normal_path, non_color=True)
        texture.label = "Normal"
        normal_map = tree.nodes.new('ShaderNodeNormalMap')
        normal_map.location = (-250, -250)
        tree.links.new(texture.outputs['Color'], normal_map.inputs['Color'])
        tree.links.new(normal_map.outputs['Normal'], principled.inputs['Normal'])

    return material, warnings


def _pick(siblings, preferred):
    for suffix in preferred:
        if suffix in siblings:
            return siblings[suffix]
    return None


class LJTM_OT_create_material(Operator):
    bl_idname = "ljtm.create_material"
    bl_label = "Create Material From Image"
    bl_description = (
        "Build a Principled material from one image_dump texture - base colour, "
        "plus normal if a sibling exists. Purely a convenience: nothing about "
        "trim syncing depends on the material"
    )
    bl_options = {'REGISTER', 'UNDO'}

    asset: EnumProperty(name="Asset", items=asset_items)
    assign_to_active: BoolProperty(
        name="Add To Active Object",
        description="Append the material as a new slot on the active mesh",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bool(settings.project_root(context))

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def execute(self, context):
        root = settings.project_root(context)
        if not root or self.asset == '__none__':
            self.report({'ERROR'}, "No project root, or image_dump is empty")
            return {'CANCELLED'}

        material, warnings = build_material(root, self.asset)
        for message in warnings:
            self.report({'WARNING'}, message)

        obj = context.active_object
        if self.assign_to_active and obj is not None and obj.type == 'MESH':
            if material.name not in [m.name for m in obj.data.materials if m]:
                obj.data.materials.append(material)
            self.report({'INFO'}, "'%s' added as slot %d"
                        % (material.name, len(obj.data.materials) - 1))
        else:
            self.report({'INFO'}, "Created material '%s'" % material.name)
        return {'FINISHED'}


class LJTM_OT_create_all_materials(Operator):
    bl_idname = "ljtm.create_all_materials"
    bl_label = "Create Materials For Whole Dump"
    bl_description = (
        "One material per asset in image_dump/. Existing materials of the same "
        "name are rewired rather than duplicated. Assigns nothing to any object"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(settings.project_root(context))

    def execute(self, context):
        root = settings.project_root(context)
        assets = project.scan_assets(root)
        if not assets:
            self.report({'ERROR'}, "image_dump is empty")
            return {'CANCELLED'}

        missing_normal = []
        for base_name, _maps in assets:
            _material, warnings = build_material(root, base_name)
            for message in warnings:
                if "no normal map" in message:
                    missing_normal.append(base_name)
                else:
                    self.report({'WARNING'}, message)

        if missing_normal:
            self.report(
                {'WARNING'},
                "No normal map for: %s" % ", ".join(missing_normal[:8])
                + (" (+%d more)" % (len(missing_normal) - 8) if len(missing_normal) > 8 else ""),
            )
        self.report({'INFO'}, "Built %d material(s)" % len(assets))
        return {'FINISHED'}


classes = (
    LJTM_OT_create_material,
    LJTM_OT_create_all_materials,
)

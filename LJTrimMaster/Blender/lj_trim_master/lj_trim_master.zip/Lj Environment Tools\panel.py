# SPDX-License-Identifier: GPL-3.0-or-later
"""The sidebar UI: per-slot rows, sync status, hook status.

Lives in the 3D Viewport's N sidebar **and** the UV/Image editor's, per Draft -
the UV editor is where the user is standing when they finish an unwrap, so the
assignment has to be reachable from there without changing editors.

Panels are read-only by contract: everything here draws from live
``projectData.json`` and the stored records, and every change goes through an
operator registered with ``{'REGISTER', 'UNDO'}`` so Ctrl+Z covers assignment
edits.

Why the picker is a dialog rather than two inline dropdowns
-----------------------------------------------------------
The design sketches inline ``[sheet v] [trim v]`` per row. The trim list has to
be filtered by the row's sheet, and an ``EnumProperty`` items callback only
receives the object the property lives on - for a per-row inline dropdown that
is the *assignment record*, which does not exist yet for an unassigned slot, and
whose enum value would be a UUID that silently invalidates whenever the project
reloads. An operator instance, by contrast, has its properties set before
``draw`` runs, so ``trim_items`` can read ``self.sheet_id`` reliably. One click
opens Sheet + Trim together, with thumbnails, and the same dialog carries the
multi-select rule.
"""

import os

import bpy
from bpy.types import Panel

from . import assignment, export_hook, settings, sidecar


class _TrimMasterPanel:
    """Shared drawing, mixed into one panel per editor."""

    bl_category = "Trim Master"

    def draw(self, context):
        layout = self.layout
        config = settings.settings(context)
        if config is None:
            layout.label(text="Scene settings unavailable", icon='ERROR')
            return

        header = layout.row()
        header.scale_y = 1.2
        header.prop(config, "enabled", toggle=True,
                    icon='CHECKMARK' if config.enabled else 'X')

        box = layout.box()
        box.prop(config, "project_root", text="")
        snapshot = settings.snapshot(context)
        if snapshot is None:
            row = box.row()
            row.alert = True
            row.label(text=settings.CACHE.error or "Set the project root", icon='ERROR')
            return
        if settings.CACHE.error:
            row = box.row()
            row.alert = True
            row.label(text=settings.CACHE.error, icon='ERROR')

        info = box.row()
        info.label(
            text="%d sheet(s), %d trim(s)" % (len(snapshot.sheets), snapshot.trim_count),
            icon='TEXTURE',
        )
        if snapshot.version != "1":
            warning = box.row()
            warning.alert = True
            warning.label(text="projectData.json is version %s" % snapshot.version,
                          icon='ERROR')

        self._draw_slots(context, layout, snapshot)


    def _draw_slots(self, context, layout, snapshot):
        obj = context.active_object
        layout.separator()
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a mesh object", icon='INFO')
            return

        mesh = obj.data
        block = assignment.mesh_trims(mesh)
        if block is not None and block.schema_version > assignment.SCHEMA_VERSION:
            row = layout.row()
            row.alert = True
            row.label(
                text="Records are schema v%d - update this add-on" % block.schema_version,
                icon='ERROR',
            )
            return

        config = settings.settings(context)
        header = layout.row()
        header.label(text=obj.name, icon='OUTLINER_OB_MESH')
        header.prop(config, "show_unassigned", text="", icon='HIDE_OFF')

        if obj.mode == 'EDIT':
            row = layout.row()
            row.alert = True
            row.label(text="In Edit Mode - exports will skip this object", icon='ERROR')

        column = layout.column(align=True)
        for slot_index in range(assignment.slot_count(mesh)):
            record = assignment.find(mesh, slot_index)
            if record is None and not config.show_unassigned:
                continue
            self._draw_slot_row(column, mesh, slot_index, record, snapshot)

        # Two objects sharing a mesh share one UV array and therefore one set of
        # assignments. Say so, rather than letting the user wonder why an edit
        # followed them across objects.
        if mesh.users > 1:
            note = layout.row()
            note.label(
                text="Mesh shared by %d objects - one set of trims. Make Single "
                     "User to split" % mesh.users,
                icon='INFO',
            )

        if assignment.assigned_records(mesh):
            layout.operator(assignment.LJTM_OT_clear_object.bl_idname, icon='X')

    def _draw_slot_row(self, layout, mesh, slot_index, record, snapshot):
        material_name = assignment.slot_material_name(mesh, slot_index)
        row = layout.row(align=True)
        row.label(text="%d" % slot_index)
        row.label(text=material_name or "(no material)", icon='MATERIAL')

        if record is None or not record.trim_id:
            picker = row.operator(
                assignment.LJTM_OT_assign_slot.bl_idname, text="- none -", icon='ADD'
            )
            picker.slot_index = slot_index
            return

        state, item = assignment.status_of(record, snapshot)
        if item is not None:
            label = "%s / %s" % (item.sheet.name, item.label)
        else:
            # Show what it *was*, so the message reads as a repair job. This is
            # the tool's normalized asset name, not a filename.
            label = "was: %s%s" % (
                record.asset_base_name or record.trim_id[:8],
                " on " + record.sheet_name if record.sheet_name else "",
            )
        picker = row.operator(assignment.LJTM_OT_assign_slot.bl_idname, text=label)
        picker.slot_index = slot_index

        status = row.row(align=True)
        status.alert = state == assignment.STATUS_MISSING_TRIM
        status.label(text="", icon=assignment.STATUS_ICONS[state])

        clear = row.operator(assignment.LJTM_OT_clear_slot.bl_idname, text="", icon='X')
        clear.slot_index = slot_index


class LJTM_PT_view3d(_TrimMasterPanel, Panel):
    bl_label = "LJ Trim Master"
    bl_idname = "LJTM_PT_view3d"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'


class LJTM_PT_uv(_TrimMasterPanel, Panel):
    bl_label = "LJ Trim Master"
    bl_idname = "LJTM_PT_uv"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'


class _SyncPanel:
    """Scene-wide status, not just the selection."""

    bl_category = "Trim Master"
    bl_label = "Sync Status"

    def draw(self, context):
        layout = self.layout
        snapshot = settings.snapshot(context)
        if snapshot is None:
            layout.label(text="Set a project root", icon='INFO')
            return

        grouped = assignment.scene_status(context.scene, snapshot)
        stale = grouped[assignment.STATUS_NEEDS_REEXPORT]
        broken = grouped[assignment.STATUS_MISSING_TRIM]
        current = grouped[assignment.STATUS_UP_TO_DATE]

        summary = layout.row(align=True)
        summary.label(text="%d" % len(current), icon='CHECKMARK')
        summary.label(text="%d" % len(stale), icon='FILE_REFRESH')
        sub = summary.row(align=True)
        sub.alert = bool(broken)
        sub.label(text="%d" % len(broken), icon='ERROR')

        if broken:
            box = layout.box()
            box.alert = True
            box.label(text="Missing trim link - re-pick manually", icon='ERROR')
            for obj, _mesh, record, _item in broken[:8]:
                row = box.row()
                row.label(
                    text="%s slot %d  was: %s"
                    % (obj.name, record.slot_index,
                       record.asset_base_name or record.trim_id[:8])
                )
            if len(broken) > 8:
                box.label(text="+%d more" % (len(broken) - 8))
            box.label(text="Re-adding the same image mints a new id, so there is "
                           "nothing safe to auto-heal to", icon='INFO')

        if stale:
            box = layout.box()
            box.label(text="Needs re-export", icon='FILE_REFRESH')
            for obj, _mesh, record, item in stale[:10]:
                row = box.row()
                row.label(
                    text="%s slot %d  %s"
                    % (obj.name, record.slot_index,
                       ("%s / %s" % (item.sheet.name, item.label)) if item else "?")
                )
            if len(stale) > 10:
                box.label(text="+%d more" % (len(stale) - 10))

        run = layout.row()
        run.scale_y = 1.3
        run.enabled = bool(stale)
        run.operator(export_hook.LJTM_OT_sync_all.bl_idname, icon='FILE_REFRESH')

        layout.separator()
        layout.menu(export_hook.LJTM_MT_export.bl_idname, icon='EXPORT')
        layout.operator(export_hook.LJTM_OT_dry_run.bl_idname, icon='CHECKMARK')


class LJTM_PT_sync_view3d(_SyncPanel, Panel):
    bl_idname = "LJTM_PT_sync_view3d"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_parent_id = "LJTM_PT_view3d"


class LJTM_PT_sync_uv(_SyncPanel, Panel):
    bl_idname = "LJTM_PT_sync_uv"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_parent_id = "LJTM_PT_uv"


class _ToolsPanel:
    bl_category = "Trim Master"
    bl_label = "Tools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        config = settings.settings(context)
        layout.operator("ljtm.create_material", icon='MATERIAL')
        layout.operator("ljtm.create_all_materials", icon='MATERIAL_DATA')
        if config:
            layout.prop(config, "show_thumbnails")

        layout.separator()
        layout.operator(sidecar.LJTM_OT_write_sidecar.bl_idname, icon='FILE_TEXT')
        root = settings.project_root(context)
        path = sidecar.sidecar_path(root, bpy.data.filepath)
        if path:
            layout.label(text=os.path.join(sidecar.LINKS_DIR, os.path.basename(path)),
                         icon='BLANK1')
        else:
            layout.label(text="Save the .blend to write a link file", icon='INFO')


class LJTM_PT_tools_view3d(_ToolsPanel, Panel):
    bl_idname = "LJTM_PT_tools_view3d"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_parent_id = "LJTM_PT_view3d"


class LJTM_PT_tools_uv(_ToolsPanel, Panel):
    bl_idname = "LJTM_PT_tools_uv"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_parent_id = "LJTM_PT_uv"


class _HooksPanel:
    bl_category = "Trim Master"
    bl_label = "Export Hooks"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, _context):
        layout = self.layout
        layout.label(text="File > Export is transparent for:")
        column = layout.column(align=True)
        for label, state in export_hook.hook_status().items():
            row = column.row()
            if state == 'HOOKED':
                row.label(text=label, icon='CHECKMARK')
            elif state == 'C_OPERATOR':
                row.label(text=label + " - use Trim-Synced Export", icon='INFO')
            elif state == 'UNAVAILABLE':
                row.label(text=label + " - add-on disabled", icon='BLANK1')
            else:
                row.alert = True
                row.label(text=label + " - NOT hooked", icon='ERROR')
        layout.operator(export_hook.LJTM_OT_attach_hooks.bl_idname, icon='FILE_REFRESH')

        leftovers = export_hook.leftover_modifiers()
        if leftovers:
            box = layout.box()
            box.alert = True
            box.label(text="%d leftover temp modifier(s)" % len(leftovers), icon='ERROR')
            box.operator(export_hook.LJTM_OT_purge_modifiers.bl_idname, icon='TRASH')


class LJTM_PT_hooks_view3d(_HooksPanel, Panel):
    bl_idname = "LJTM_PT_hooks_view3d"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_parent_id = "LJTM_PT_view3d"


class LJTM_PT_hooks_uv(_HooksPanel, Panel):
    bl_idname = "LJTM_PT_hooks_uv"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_parent_id = "LJTM_PT_uv"


classes = (
    LJTM_PT_view3d,
    LJTM_PT_sync_view3d,
    LJTM_PT_tools_view3d,
    LJTM_PT_hooks_view3d,
    LJTM_PT_uv,
    LJTM_PT_sync_uv,
    LJTM_PT_tools_uv,
    LJTM_PT_hooks_uv,
)

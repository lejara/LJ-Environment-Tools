# SPDX-License-Identifier: GPL-3.0-or-later
"""Scene-level settings and the one shared project cache.

The project root lives on the **Scene**, not in add-on preferences, so it saves
with the ``.blend``. A ``.blend`` belongs to a project the same way its per-slot
assignments do; putting the root in a machine-wide preference would mean opening
a second project's file silently pointed the assignments at the wrong sheets.

This module exists so that everything else can reach the cache without importing
``__init__``, which would be circular.
"""

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import PropertyGroup

from . import project

#: The single ``projectData.json`` reader. Module-level, so the panel, the
#: export hook and the sidecar writer all see the same mtime cache.
CACHE = project.ProjectCache()


def _on_root_change(self, _context):
    CACHE.invalidate()


class LJTM_Settings(PropertyGroup):
    project_root: StringProperty(
        name="Project Root",
        description=(
            "Folder containing projectData.json, image_dump/ and output/. "
            "Saved with this .blend"
        ),
        subtype='DIR_PATH',
        update=_on_root_change,
    )
    enabled: BoolProperty(
        name="Transform On Export",
        description=(
            "Master switch. When off, exports are byte-for-byte what Blender "
            "would normally write - and nothing is synced"
        ),
        default=True,
    )
    show_unassigned: BoolProperty(
        name="Show Unassigned Slots",
        description="List material slots with no trim assigned",
        default=True,
    )
    show_thumbnails: BoolProperty(
        name="Thumbnails",
        description=(
            "Load image_dump/ previews for the trim pickers. Turn off if a very "
            "large dump makes the panel sluggish"
        ),
        default=True,
    )


def settings(context):
    scene = getattr(context, "scene", None)
    return getattr(scene, "lj_trim_master", None) if scene else None


def project_root(context):
    """Absolute project root, or ``""``. Resolves Blender's ``//`` prefix."""
    config = settings(context)
    if config is None or not config.project_root:
        return ""
    return bpy.path.abspath(config.project_root).rstrip("\\/")


def snapshot(context, force=False):
    """Current ``projectData.json``, reloaded if it changed on disk."""
    return CACHE.get(project_root(context), force=force)


def is_enabled(context):
    config = settings(context)
    return bool(config and config.enabled)


def is_thumbnails_enabled(context):
    config = settings(context)
    return bool(config and config.show_thumbnails)


classes = (LJTM_Settings,)


def register():
    bpy.types.Scene.lj_trim_master = bpy.props.PointerProperty(type=LJTM_Settings)


def unregister():
    del bpy.types.Scene.lj_trim_master

# SPDX-License-Identifier: GPL-3.0-or-later
"""Reads ``projectData.json`` and the project's ``image_dump/``.

**Read-only, always.** The add-on never writes ``projectData.json`` and never
writes UVs into the ``.blend``. The only thing it writes into the project is the
sidecar link file (see ``sidecar.py``), which the tool treats as advisory.

Nothing the add-on stores is allowed to disagree with this file, so the sheet, a
sheet's resolution and a trim's transform are re-read here on every panel draw
and every export rather than cached in the ``.blend``. The cache below exists
only to avoid re-parsing JSON on every UI redraw; it invalidates on mtime.

The tool autosaves 800 ms after every edit, so a read can land mid-write. The
tool writes temp-then-rename to make that atomic, but this reader still keeps the
previous snapshot on a parse error instead of blanking the panel - an older
version of the truth beats none.
"""

import json
import os
import time

__all__ = [
    "TrimItem",
    "Sheet",
    "ProjectSnapshot",
    "ProjectCache",
    "DATA_FILE",
    "IMAGE_DUMP",
    "normalize_base_name",
    "find_asset_image",
    "scan_assets",
]

DATA_FILE = "projectData.json"
IMAGE_DUMP = "image_dump"
OUTPUT_DIR = "output"

#: The tool's ``maps.yaml`` lists these as the delimiters that may separate a
#: base name from its map suffix. The add-on cannot read that file - it lives
#: next to the tool binary, not in the project - so it assumes the full set,
#: which is what the tool's own default normalization does anyway.
SUFFIX_DELIMS = ("_", "-", ".")

#: Preferred suffixes when picking one file out of an asset's siblings to show
#: as a thumbnail. First match wins; a file with no suffix at all comes next.
BASE_COLOR_SUFFIXES = ("basecolor", "albedo", "diffuse", "color", "basemap", "col")

#: Suffix that marks a normal map, for ``material.py``'s convenience builder.
NORMAL_SUFFIXES = ("normal", "normalgl", "normaldx", "nrm", "norm")

IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".tga", ".tif", ".tiff", ".bmp", ".exr")


def normalize_base_name(name):
    """Collapse every suffix delimiter to a single ``_``, as the tool does.

    This is why ``old-wood_Normal.png`` and ``old_wood-AO.png`` group into one
    asset called ``old_wood``. The add-on has to reproduce it to match a stored
    ``assetBaseName`` against a file on disk.
    """
    text = name
    for delim in SUFFIX_DELIMS:
        text = text.replace(delim, "_")
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_")


class TrimItem:
    """One trim instance placed on a sheet."""

    __slots__ = ("id", "asset_base_name", "position", "scale", "rotation", "crop", "sheet")

    def __init__(self, id, asset_base_name, position, scale, rotation, crop, sheet):
        self.id = id
        self.asset_base_name = asset_base_name
        self.position = position
        self.scale = scale
        self.rotation = rotation
        self.crop = crop
        self.sheet = sheet

    @property
    def label(self):
        return self.asset_base_name or self.id[:8]


class Sheet:
    """One trim sheet."""

    __slots__ = ("id", "name", "resolution", "enabled_preset_names", "items")

    def __init__(self, id, name, resolution, enabled_preset_names, items):
        self.id = id
        self.name = name
        self.resolution = resolution
        self.enabled_preset_names = enabled_preset_names
        self.items = items


class ProjectSnapshot:
    """One successful parse of ``projectData.json``."""

    __slots__ = ("root", "version", "default_resolution", "sheets", "_trims", "stamp")

    def __init__(self, root, version, default_resolution, sheets, stamp):
        self.root = root
        self.version = version
        self.default_resolution = default_resolution
        self.sheets = sheets
        self.stamp = stamp
        self._trims = {}
        for sheet in sheets:
            for item in sheet.items:
                # A project-wide duplicate id would make resolution ambiguous.
                # The tool re-mints duplicates on load; first-wins here just
                # keeps a hand-edited file from crashing the panel.
                self._trims.setdefault(item.id, item)

    def find_trim(self, trim_id):
        """The only trim resolution path. ``assetBaseName`` is never a key."""
        return self._trims.get(trim_id) if trim_id else None

    def find_sheet(self, sheet_id):
        for sheet in self.sheets:
            if sheet.id == sheet_id:
                return sheet
        return None

    @property
    def trim_count(self):
        return len(self._trims)

    @property
    def image_dump(self):
        return os.path.join(self.root, IMAGE_DUMP)

    @classmethod
    def parse(cls, root, raw, stamp):
        sheets = []
        for raw_sheet in raw.get("sheets") or []:
            resolution = _resolution(raw_sheet.get("resolution"), (2048, 2048))
            sheet = Sheet(
                id=str(raw_sheet.get("id") or ""),
                name=str(raw_sheet.get("name") or "(unnamed)"),
                resolution=resolution,
                enabled_preset_names=list(raw_sheet.get("enabledPresetNames") or []),
                items=[],
            )
            for raw_item in raw_sheet.get("items") or []:
                transform = raw_item.get("transform") or {}
                crop = raw_item.get("crop") or {}
                sheet.items.append(
                    TrimItem(
                        id=str(raw_item.get("id") or ""),
                        asset_base_name=str(raw_item.get("assetBaseName") or ""),
                        position=_vec2(transform.get("position"), (0.5, 0.5)),
                        scale=_vec2(transform.get("scale"), (0.25, 0.25)),
                        rotation=_number(transform.get("rotation"), 0.0),
                        crop=_vec2(crop, (0.0, 0.0)),
                        sheet=sheet,
                    )
                )
            sheets.append(sheet)

        defaults = raw.get("defaults") or {}
        return cls(
            root=root,
            version=str(raw.get("version") or "?"),
            default_resolution=_resolution(
                defaults.get("defaultTrimResolution"), (2048, 2048)
            ),
            sheets=sheets,
            stamp=stamp,
        )


class ProjectCache:
    """mtime-keyed loader. One instance lives at module scope in ``__init__``."""

    #: A panel redraws far more often than the file changes, and the project may
    #: sit on a synced drive where ``stat`` is not free.
    STAT_INTERVAL = 0.4

    def __init__(self):
        self._root = None
        self._snapshot = None
        self._error = None
        self._checked_at = 0.0

    @property
    def error(self):
        """Last load failure, or None. Kept alongside a stale snapshot."""
        return self._error

    @property
    def snapshot(self):
        """Whatever was last parsed, without touching the disk."""
        return self._snapshot

    def invalidate(self):
        self._checked_at = 0.0
        if self._root is None:
            self._snapshot = None

    def get(self, root, force=False):
        """Current snapshot for *root*, reloading if the file changed."""
        root = (root or "").strip()
        if not root:
            self._root = None
            self._snapshot = None
            self._error = None
            return None

        if root != self._root:
            self._root = root
            self._snapshot = None
            self._error = None
            force = True

        now = time.monotonic()
        if not force and (now - self._checked_at) < self.STAT_INTERVAL:
            return self._snapshot
        self._checked_at = now

        path = os.path.join(root, DATA_FILE)
        try:
            info = os.stat(path)
        except OSError:
            self._snapshot = None
            self._error = "No %s in \"%s\"" % (DATA_FILE, root)
            return None

        stamp = (info.st_mtime_ns, info.st_size)
        if self._snapshot is not None and self._snapshot.stamp == stamp:
            self._error = None
            return self._snapshot

        try:
            with open(path, "r", encoding="utf-8") as handle:
                raw = json.load(handle)
        except (OSError, ValueError) as err:
            # Most likely a read that raced the tool's autosave. Keep the
            # previous snapshot and retry on the next poll.
            self._error = "%s could not be read: %s" % (DATA_FILE, err)
            self._checked_at = 0.0
            return self._snapshot

        if not isinstance(raw, dict):
            self._error = "%s is not an object" % DATA_FILE
            return self._snapshot

        self._snapshot = ProjectSnapshot.parse(root, raw, stamp)
        self._error = None
        return self._snapshot


# ---------------------------------------------------------------------------
# image_dump lookup
# ---------------------------------------------------------------------------

def asset_siblings(root, asset_base_name):
    """Every ``image_dump/`` file belonging to *asset_base_name*.

    Returns ``[(suffix_lowercase, absolute_path), ...]``, suffix ``""`` for a
    file with no map suffix.

    Matching is on the *normalized* name, so it groups the same way the tool
    does. It cannot be exact: the tool only splits off a suffix that appears in
    ``maps.yaml``, which lives next to the tool binary and is unreadable from
    here, so ``old_wood_v2.png`` reads as a sibling of ``old_wood`` here and as
    its own asset in the tool. That only ever picks a different thumbnail.
    """
    if not root or not asset_base_name:
        return []
    target = normalize_base_name(asset_base_name).lower()
    if not target:
        return []
    folder = os.path.join(root, IMAGE_DUMP)
    try:
        names = os.listdir(folder)
    except OSError:
        return []

    found = []
    for name in names:
        stem, extension = os.path.splitext(name)
        if extension.lower() not in IMAGE_EXTENSIONS:
            continue
        normalized = normalize_base_name(stem).lower()
        if normalized == target:
            found.append(("", os.path.join(folder, name)))
        elif normalized.startswith(target + "_"):
            found.append((normalized[len(target) + 1:], os.path.join(folder, name)))
    found.sort(key=lambda pair: (pair[0] != "", pair[0]))
    return found


def scan_assets(root):
    """Group ``image_dump/`` into assets, the way the tool's Assets panel does.

    Returns ``[(base_name, {suffix_lowercase: path}), ...]`` sorted by name.

    Approximate for the same reason as :func:`asset_siblings`: without
    ``maps.yaml`` the add-on cannot tell a map suffix from part of a base name,
    so it treats the first delimiter-separated tail as a suffix when the head is
    shared with another file. Only ever used to populate a convenience picker.
    """
    folder = os.path.join(root or "", IMAGE_DUMP)
    try:
        names = sorted(os.listdir(folder))
    except OSError:
        return []

    stems = []
    for name in names:
        stem, extension = os.path.splitext(name)
        if extension.lower() in IMAGE_EXTENSIONS:
            stems.append((normalize_base_name(stem), os.path.join(folder, name)))

    normalized = {stem for stem, _ in stems}
    grouped = {}
    for stem, path in stems:
        base, _, tail = stem.rpartition("_")
        # "wood_Normal" is a sibling of "wood" only if some other file agrees
        # that "wood" is the base - otherwise the whole stem is the base name.
        if base and (base in normalized or any(
                other.startswith(base + "_") and other != stem for other in normalized)):
            grouped.setdefault(base, {})[tail.lower()] = path
        else:
            grouped.setdefault(stem, {})[""] = path
    return sorted(grouped.items())


def find_asset_image(root, asset_base_name, prefer=BASE_COLOR_SUFFIXES):
    """One representative file for an asset, or None.

    Used for thumbnails and for the Create Material convenience button. Prefers
    a base-colour-ish suffix, then a suffix-less file, then anything.
    """
    siblings = asset_siblings(root, asset_base_name)
    if not siblings:
        return None
    for wanted in prefer:
        for suffix, path in siblings:
            if suffix == wanted:
                return path
    for suffix, path in siblings:
        if suffix == "":
            return path
    return siblings[0][1]


# ---------------------------------------------------------------------------

def _number(value, default):
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return default if result != result else result  # NaN guard


def _vec2(raw, default):
    if not isinstance(raw, dict):
        return default
    return (_number(raw.get("x"), default[0]), _number(raw.get("y"), default[1]))


def _resolution(raw, default):
    if not isinstance(raw, dict):
        return default
    width = int(_number(raw.get("width"), default[0]))
    height = int(_number(raw.get("height"), default[1]))
    return (max(width, 1), max(height, 1))

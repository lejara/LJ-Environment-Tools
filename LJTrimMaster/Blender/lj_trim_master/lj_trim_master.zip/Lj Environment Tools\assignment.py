# SPDX-License-Identifier: GPL-3.0-or-later
"""Per-material-slot trim assignments, stored on the **mesh**.

Why the mesh and not the object: ``material_index`` is mesh polygon data, and a
material slot links ``mesh.materials`` by default, so both halves of "which
faces get this trim" are mesh-level. Two objects sharing a mesh datablock share
one UV array - they physically cannot carry different transforms - so storing
per-object would invent a distinction the data cannot honour.

What is stored, and what each field is for:

===================  ========================================================
``schema_version``   On the mesh. Bump when a record's shape changes.
``slot_index``       Which face group. ``polygon.material_index``.
``material_name``    Repair only - the user can reorder slots.
``trim_id``          **The** identity, and the only resolution key.
``asset_base_name``  **Label only.** Never used for matching.
``sheet_name``       Label only, for the missing-link message.
``last_export``      Trim state at last export. Informational.
===================  ========================================================

**Nothing here can go stale into a wrong export.** The sheet, its resolution and
the transform are re-read from ``projectData.json`` on every panel draw and
every export, so a bad record can only produce a wrong *list* - never wrong UVs.

``asset_base_name`` is the tool's **normalized** name: ``old-wood_Normal.png``
and ``old_wood-AO.png`` both collapse to ``old_wood``. It may therefore match no
file on disk exactly, which is why the UI never presents it as a filename.
"""

from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
    StringProperty,
)
from bpy.types import Operator, PropertyGroup

from . import settings, thumbnails

__all__ = [
    "SCHEMA_VERSION",
    "STATUS_UP_TO_DATE",
    "STATUS_NEEDS_REEXPORT",
    "STATUS_MISSING_TRIM",
    "LJTM_SlotAssignment",
    "LJTM_MeshTrims",
]

#: Shape of one ``LJTM_SlotAssignment``. Bump when a field's meaning changes.
SCHEMA_VERSION = 1

STATUS_UP_TO_DATE = 'UP_TO_DATE'
STATUS_NEEDS_REEXPORT = 'NEEDS_REEXPORT'
STATUS_MISSING_TRIM = 'MISSING_TRIM'

STATUS_LABELS = {
    STATUS_UP_TO_DATE: "up to date",
    STATUS_NEEDS_REEXPORT: "needs re-export",
    STATUS_MISSING_TRIM: "missing trim link",
}

STATUS_ICONS = {
    STATUS_UP_TO_DATE: 'CHECKMARK',
    STATUS_NEEDS_REEXPORT: 'FILE_REFRESH',
    STATUS_MISSING_TRIM: 'ERROR',
}

NO_TRIM = '__none__'


# ---------------------------------------------------------------------------
# Stored data
# ---------------------------------------------------------------------------

class LJTM_SlotAssignment(PropertyGroup):
    slot_index: IntProperty(name="Slot", default=0, min=0)
    material_name: StringProperty(name="Material")
    trim_id: StringProperty(name="Trim")
    asset_base_name: StringProperty(name="Asset")
    sheet_name: StringProperty(name="Sheet")
    last_export: StringProperty(
        name="Last Export",
        description="Trim state when this slot was last exported. Informational",
    )


class LJTM_MeshTrims(PropertyGroup):
    schema_version: IntProperty(default=0)
    slots: CollectionProperty(type=LJTM_SlotAssignment)
    last_export_replay: StringProperty(
        name="Last Export Replay",
        description=(
            "JSON snapshot of the exporter and the exact property values that "
            "last wrote this mesh. Sync All And Reexport replays it verbatim - "
            "without it, a re-export would silently use the exporter's defaults "
            "instead of the settings the user actually exported with"
        ),
    )


def mesh_trims(mesh):
    """The assignment block on *mesh*, migrated to the current schema."""
    block = getattr(mesh, "lj_trim_master", None)
    if block is None:
        return None
    if block.schema_version != SCHEMA_VERSION:
        _migrate(mesh, block)
    return block


def _migrate(mesh, block):
    """Bring an older record shape forward.

    Nothing to do at version 1 - this is the seam. A record written by a future
    version is left alone and reported by the panel rather than silently
    reinterpreted.
    """
    if block.schema_version > SCHEMA_VERSION:
        return
    block.schema_version = SCHEMA_VERSION


def records(mesh):
    block = mesh_trims(mesh)
    return list(block.slots) if block else []


def assigned_records(mesh):
    """Records that actually name a trim."""
    return [record for record in records(mesh) if record.trim_id]


def find(mesh, slot_index):
    for record in records(mesh):
        if record.slot_index == slot_index:
            return record
    return None


def assign(mesh, slot_index, item):
    """Point *slot_index* at *item*. Creates the record if there is none."""
    block = mesh_trims(mesh)
    if block is None:
        return None
    record = find(mesh, slot_index)
    if record is None:
        record = block.slots.add()
        record.slot_index = slot_index
    record.material_name = slot_material_name(mesh, slot_index)
    record.trim_id = item.id
    record.asset_base_name = item.asset_base_name
    record.sheet_name = item.sheet.name
    record.last_export = ""
    return record


def clear(mesh, slot_index):
    block = mesh_trims(mesh)
    if block is None:
        return False
    for index, record in enumerate(block.slots):
        if record.slot_index == slot_index:
            block.slots.remove(index)
            return True
    return False


def clear_all(mesh):
    block = mesh_trims(mesh)
    if block is None:
        return 0
    count = len(block.slots)
    block.slots.clear()
    return count


def slot_material_name(mesh, slot_index):
    if 0 <= slot_index < len(mesh.materials):
        material = mesh.materials[slot_index]
        return material.name if material else ""
    return ""


def slot_count(mesh):
    """Number of face groups. A mesh with no materials still has slot 0."""
    return max(len(mesh.materials), 1)


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

def signature(item):
    """Everything about a trim that changes its UVs, as one comparable string.

    Fixed precision on purpose: a JSON round trip perturbs floats in the last
    bits, and a phantom "needs re-export" on every project reload would make the
    list useless. 1e-7 normalized is 0.0002 px on a 2048 sheet.
    """
    sheet = item.sheet
    return "%s:%dx%d:%.7f,%.7f:%.7f,%.7f:%.5f:%.7f,%.7f" % (
        sheet.id,
        sheet.resolution[0],
        sheet.resolution[1],
        item.position[0],
        item.position[1],
        item.scale[0],
        item.scale[1],
        item.rotation,
        item.crop[0],
        item.crop[1],
    )


def status_of(record, snapshot):
    """``(status, item_or_None)`` for one record against live project data.

    A trim that moved, a sheet that was resized, and a trim moved to another
    sheet all land on ``NEEDS_REEXPORT`` - the signature carries the sheet id and
    resolution, so all three change it. A never-exported record is folded in
    there too: it also needs an export to become correct.
    """
    if snapshot is None:
        return (STATUS_NEEDS_REEXPORT, None)
    item = snapshot.find_trim(record.trim_id)
    if item is None:
        return (STATUS_MISSING_TRIM, None)
    if record.last_export and record.last_export == signature(item):
        return (STATUS_UP_TO_DATE, item)
    return (STATUS_NEEDS_REEXPORT, item)


def mark_exported(record, item):
    record.last_export = signature(item)
    record.asset_base_name = item.asset_base_name
    record.sheet_name = item.sheet.name


def iter_scene_assignments(scene):
    """``(obj, mesh, record)`` for every assigned slot in *scene*, deduped.

    Deduped on the mesh, because two objects sharing a datablock share the one
    UV array and the one set of records. The first object encountered is the one
    reported, which is only ever used for a label.
    """
    seen = set()
    for obj in scene.objects:
        if obj.type != 'MESH' or obj.data is None:
            continue
        key = obj.data.as_pointer()
        if key in seen:
            continue
        seen.add(key)
        for record in assigned_records(obj.data):
            yield (obj, obj.data, record)


def scene_status(scene, snapshot):
    """Group every assignment in the scene by status, for the panel and Sync."""
    grouped = {
        STATUS_UP_TO_DATE: [],
        STATUS_NEEDS_REEXPORT: [],
        STATUS_MISSING_TRIM: [],
    }
    for obj, mesh, record in iter_scene_assignments(scene):
        state, item = status_of(record, snapshot)
        grouped[state].append((obj, mesh, record, item))
    return grouped


# ---------------------------------------------------------------------------
# Enum items for the pickers
#
# Blender does not keep a reference to strings returned from an items callback,
# so they have to be held alive here or the menu draws garbage.
# ---------------------------------------------------------------------------

_ENUM_KEEPALIVE = {}


def sheet_items(_self, context):
    snapshot = settings.snapshot(context)
    items = []
    if snapshot:
        for sheet in snapshot.sheets:
            items.append((
                sheet.id,
                sheet.name,
                "%d x %d, %d trim(s)"
                % (sheet.resolution[0], sheet.resolution[1], len(sheet.items)),
            ))
    if not items:
        items = [(NO_TRIM, "(no sheets)", "Set a project root with at least one sheet")]
    _ENUM_KEEPALIVE["sheets"] = items
    return items


def trim_items(self, context):
    """Trims on the sheet this operator currently has selected.

    Reads ``self.sheet_id``, which is why the picker is a dialog: an operator
    instance has its properties set before ``draw`` runs, so the second dropdown
    can be filtered by the first. A per-row inline dropdown has no such instance
    to hang the filter on.
    """
    snapshot = settings.snapshot(context)
    sheet = snapshot.find_sheet(getattr(self, "sheet_id", "")) if snapshot else None
    items = []
    if sheet:
        show_thumbnails = settings.is_thumbnails_enabled(context)
        for item in sheet.items:
            icon = thumbnails.icon_for(snapshot.root, item.asset_base_name) if show_thumbnails else 0
            entry = (item.id, item.label, "trim_id %s" % item.id)
            # The 5-tuple form carries an icon_value, so the dropdown shows the
            # texture itself. 0 is not a valid icon_value, hence the branch.
            items.append(entry + (icon, 0) if icon else entry)
    if not items:
        items = [(NO_TRIM, "(no trims on this sheet)", "Add an image to the sheet in LJ Trim Master")]
    _ENUM_KEEPALIVE["trims"] = items
    return items


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class LJTM_OT_assign_slot(Operator):
    bl_idname = "ljtm.assign_slot"
    bl_label = "Assign Trim"
    bl_description = "Point this material slot at a trim on a sheet"
    bl_options = {'REGISTER', 'UNDO'}

    slot_index: IntProperty(name="Slot", default=0, min=0, options={'SKIP_SAVE'})
    sheet_id: EnumProperty(name="Sheet", items=sheet_items, options={'SKIP_SAVE'})
    trim_id: EnumProperty(name="Trim", items=trim_items, options={'SKIP_SAVE'})
    apply_to_selected: BoolProperty(
        name="Apply To All Selected",
        description=(
            "Also assign the matching slot on every other selected mesh - by "
            "material name where there is one, otherwise by slot index. Draft's "
            "rule: a mixed selection takes whatever you pick"
        ),
        default=True,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(obj and obj.type == 'MESH')

    def invoke(self, context, _event):
        snapshot = settings.snapshot(context, force=True)
        if snapshot is None:
            self.report({'ERROR'}, "Set a valid project root first")
            return {'CANCELLED'}

        # Seed the dialog from whatever the slot already points at.
        mesh = context.active_object.data
        record = find(mesh, self.slot_index)
        if record and record.trim_id:
            item = snapshot.find_trim(record.trim_id)
            if item is not None:
                self.sheet_id = item.sheet.id
                self.trim_id = item.id
        self.apply_to_selected = len(_selected_meshes(context)) > 1
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        mesh = obj.data
        layout.label(
            text="Slot %d - %s"
            % (self.slot_index, slot_material_name(mesh, self.slot_index) or "(no material)"),
            icon='MATERIAL',
        )
        layout.prop(self, "sheet_id")
        layout.prop(self, "trim_id")
        if len(_selected_meshes(context)) > 1:
            layout.prop(self, "apply_to_selected")

    def execute(self, context):
        snapshot = settings.snapshot(context, force=True)
        if snapshot is None:
            self.report({'ERROR'}, "Set a valid project root first")
            return {'CANCELLED'}
        item = snapshot.find_trim(self.trim_id)
        if item is None:
            self.report({'ERROR'}, "Pick a trim")
            return {'CANCELLED'}

        active = context.active_object
        targets = [active.data]
        source_material = slot_material_name(active.data, self.slot_index)
        if self.apply_to_selected:
            for obj in _selected_meshes(context):
                if obj.data not in targets:
                    targets.append(obj.data)

        applied = 0
        skipped = []
        for mesh in targets:
            slot = self.slot_index if mesh is active.data else _matching_slot(
                mesh, self.slot_index, source_material
            )
            if slot is None:
                skipped.append(mesh.name)
                continue
            if assign(mesh, slot, item) is not None:
                applied += 1

        from . import sidecar
        sidecar.write_for_scene(context, report=lambda msg: self.report({'WARNING'}, msg))

        for name in skipped:
            self.report({'WARNING'}, "'%s' has no matching slot - skipped" % name)
        self.report(
            {'INFO'},
            "%s on %s -> %d mesh(es)" % (item.label, item.sheet.name, applied),
        )
        return {'FINISHED'}


class LJTM_OT_clear_slot(Operator):
    bl_idname = "ljtm.clear_slot"
    bl_label = "Clear Trim"
    bl_description = "Remove this slot's trim assignment"
    bl_options = {'REGISTER', 'UNDO'}

    slot_index: IntProperty(default=0, min=0, options={'SKIP_SAVE'})
    all_selected: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(obj and obj.type == 'MESH')

    def execute(self, context):
        active = context.active_object
        source_material = slot_material_name(active.data, self.slot_index)
        meshes = [active.data]
        if self.all_selected:
            for obj in _selected_meshes(context):
                if obj.data not in meshes:
                    meshes.append(obj.data)

        removed = 0
        for mesh in meshes:
            slot = self.slot_index if mesh is active.data else _matching_slot(
                mesh, self.slot_index, source_material
            )
            if slot is not None and clear(mesh, slot):
                removed += 1

        from . import sidecar
        sidecar.write_for_scene(context)
        self.report({'INFO'}, "Cleared %d assignment(s)" % removed)
        return {'FINISHED'}


class LJTM_OT_clear_object(Operator):
    bl_idname = "ljtm.clear_object"
    bl_label = "Clear All Trims On Object"
    bl_description = "Remove every trim assignment from the active object's mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(obj and obj.type == 'MESH' and assigned_records(obj.data))

    def execute(self, context):
        removed = clear_all(context.active_object.data)
        from . import sidecar
        sidecar.write_for_scene(context)
        self.report({'INFO'}, "Cleared %d assignment(s)" % removed)
        return {'FINISHED'}


def _selected_meshes(context):
    meshes = [obj for obj in context.selected_objects if obj.type == 'MESH' and obj.data]
    active = context.active_object
    if active is not None and active.type == 'MESH' and active not in meshes:
        meshes.insert(0, active)
    return meshes


def _matching_slot(mesh, slot_index, material_name):
    """Which slot on *mesh* corresponds to the one the user clicked.

    By material name when the source slot has one, because slot *order* is
    arbitrary and a shared material is the real correspondence. Falls back to the
    index.
    """
    if material_name:
        for index, material in enumerate(mesh.materials):
            if material is not None and material.name == material_name:
                return index
    if slot_index < slot_count(mesh):
        return slot_index
    return None


classes = (
    LJTM_SlotAssignment,
    LJTM_MeshTrims,
    LJTM_OT_assign_slot,
    LJTM_OT_clear_slot,
    LJTM_OT_clear_object,
)
